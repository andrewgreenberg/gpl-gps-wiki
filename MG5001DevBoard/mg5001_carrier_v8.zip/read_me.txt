--------------------------------------------------------------------------
GPL-GPS Project: The MG5001 Development Carrier Board
--------------------------------------------------------------------------

Andrew Greenberg
08/30/2003

Files in this archive:

    EAGLE CAD (http://www.cadsoft.de/) design files:
    
        mg5001_carrier_v8.sch: EAGLE schematic
        mg5001_carrier_v8.brd: EAGLE board layout
        
    Misc:
    
        mg5001_carrier_v8.bom: EAGLE Bill of Materials (parts)
        mg5001_carrier_v8.pdf: PDF of the EAGLE schematic
 
 Have any questions? Email me at andrew@uad.com.
 