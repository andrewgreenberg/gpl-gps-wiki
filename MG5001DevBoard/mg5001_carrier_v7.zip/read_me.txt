--------------------------------------------------------------------------
MG5001 Development "Carrier" Board
--------------------------------------------------------------------------

Andrew Greenberg
08/13/2003

Files in this archive:

    EAGLE CAD (http://www.cadsoft.de/) design files:
    
        mg5001_carrier_v7.sch: Schematic
        mg5001_carrier_v7.brd: Board Layout
        mg5001_carrier_v7.cam: Geber file creation settings
        
    Geber files (PCB manufacturing files):
    
        mg5001_carrier_v7.top: Top (component) layer
        mg5001_carrier_v7.bot: Bottom (solder) layer
        mg5001_carrier_v7.xln: Excellon drill file
        mg5001_carrier_v7.drl: Excellon drill rack (list of drills)
 
 Have any questions? Email me at andrew@uad.com.
 